
 StdUtils plug-in for NSIS
 Copyright (C) 2004-2018 LoRd_MuldeR <mulder2@gmx.de>

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

 http://www.gnu.org/licenses/lgpl-2.1.txt

 ----

 The author of the StdUtils plug-in Library for NSIS adds the
 following clarification to the GNU Lesser General Public License
 version 2.1: Installer programs (executables) created with NSIS
 (Nullsoft Scriptable Install System) that make use of the StdUtils
 plug-in Library (strictly through the NSIS plug-in interface) and
 that contain/distribute verbatim copies of the StdUtils plug-in
 Library are considered a "work that uses the Library"; they do NOT
 represent a derivative of the Library.

 ----

 Update Windows 10 edition name "19H1" to "Redstone 6" for version 1903.

 VictorVG, 13.07.2019 12:09:02 +0300