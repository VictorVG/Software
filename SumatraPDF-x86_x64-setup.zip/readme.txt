SumatraPDF Reader 
 
SumatraPDF is a multi-format (PDF, EPUB, MOBI, FB2, CHM, XPS, DjVu) reader for 
Windows under (A)GPLv3 license, with some code under BSD license (see AUTHORS). 
 
More information: 
 
* main website http://www.sumatrapdfreader.org with downloads and documentation 
* manual https://www.sumatrapdfreader.org/manual.html 
* all other docs https://www.sumatrapdfreader.org/docs/SumatraPDF-documentation.html 
 
To compile you need Visual Studio 2019 Free Community edition 
https://www.visualstudio.com/vs/community/ works. 
I tend to update to the latest release of Visual Studio. Lately C++ evolves 
quickly and Visual Studio constantly adds latest capabilities. If things 
don't compile, first make sure you're using the latest update of Visual Studio. 
 
To get the code: 
 
git clone git@github.com:sumatrapdfreader/sumatrapdf.git 
 
Open "vs2019\SumatraPDF.sln" and compile use Visual Studio 2019 
