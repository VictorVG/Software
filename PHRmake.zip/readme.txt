PHRmake toolkit v1.2 for Process Hacker v3.0 Russian translation by KLASS.

Copyright � VictorVG @ VikSoft.Ru, 1996 - 2018.

REQUIRED:

Write for Process Hacker v3.0.5719.1192 or never.

PARAMETERS: none

USAGE:

Just place source archive "processhacker_v3.0_RUS.7z" in to some folder thats
is located "phrmake.exe", run "phrmake" and wait finish.

SYNOPSIS:

This toolkit is automatically make installer for Russian translation by KLASS.

After run "phrmake.exe" renamed source archive to "processhacker_3.0_RUS.7z",
then unpacked it and make installer "processhacker-3.0-RU-setup.exe", before
clean working folder and automatically exit.

Program topic: http://forum.ru-board.com/topic.cgi?forum=5&topic=29703&glp
Translation topic: http://forum.ru-board.com/topic.cgi?forum=2&topic=5350&glp

VictorVG, 23.02.2018 00:44:22 +0300
