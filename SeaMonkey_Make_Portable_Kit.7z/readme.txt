Usage:

1) Unpack archive "SeaMonkey_Make_Portable_Kit.7z" in to any dir
2) Copy only "SeaMonkey Setup *.exe" or seamonkey-*.*.zip in to
   ./SeaMonkey_Make_Portable_Kit
3) Open CMD console and type cd /d $path\SeaMonkey_Make_Portable_Kit and press
   Enter
4) type "makeport x86" for 32 bit SeaMonkey or "makeport x64" for 64 bit
   SeaMonkey and press Enter
5) Please wait for end makeport.cmd then Your have portable version SeaMonkey.