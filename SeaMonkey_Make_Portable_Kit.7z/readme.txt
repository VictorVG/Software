SeaMonkey make portable toolkit v2.1 for Windows.

Parameters required: x86 or x64

Supported:

Botch x86 and x64 SeaMonkey release version 2.11 or newer,

System required:

OS Windows XP SP3 or newer, up to 500 Mb om disk space for working.

Usage:

1) Unpack this toolkit this save dir tree in to working dir.
2) Put only one source file name as "SeaMonkey Setup *.exe" or
   "seamonkey-*.installer.exe" or seamonkey-*.*.zip in to  working dir.
   ./SeaMonkey_Make_Portable_Kit
3) Type "makeport x86" for 32 bit SeaMonkey or "makeport x64" for 64 bit
   SeaMonkey and press Enter.
4) Please wait on toolkit create portable copy of SeaMonkey in to
   "./SeaMonkey portable" dir and display final messages.

History:

v2.0, 26.08.2019 20:05:23 +0300

   * Both x86 and x64 edition support,
   * Support SeaMonkey v2.52+ (rv55 or newer)
   * Refactoring.

v2.1, 30.08.2019 21:00:29 +0300

   * Fix problem "SeaMonkey v2.11 - v2.48 don't start as portable".
   * Fix bug "Toolkit don't run in Win32"
   * Refactoring.

v2.2, 31.08.2019 01:58:00 +0300

   * Update ZH_CN NetWork tmemutil.dll v5.0.5.300
   * Fix problem "Can't read UTF-16 LE coded tmemutil.ini" (undocumented).