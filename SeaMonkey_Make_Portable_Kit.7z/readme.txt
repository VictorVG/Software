SeaMonkey make portable toolkit v2.1 for Windows.

Parameters required: x86 or x64

Supported:

Botch x86 and x64 SeaMonkey relese version 2.10 or newer

Usage:

1) Unpack this toolkit this save dir tree in to working dir.
2) Put only one source file name as "SeaMonkey Setup *.exe" or
   "seamonkey-*.installer.exe" or seamonkey-*.*.zip in to  working dir.
   ./SeaMonkey_Make_Portable_Kit
3) Type "makeport x86" for 32 bit SeaMonkey or "makeport x64" for 64 bit
   SeaMonkey and press Enter.
4) Please wait on toolkit create portable copy of SeaMonkey in to
   "./SeaMonkey portabe" dir and display final messages.

History:

v2.0, 26.08.2019 20:05:23 +0300

   * Both x86 and x64 edition support,
   * Support SeaMonkey v2.52+ (rv55 or newer)
   * Refactoring.

v2.1, 30.08.2019 21:00:29 +0300

   * Fix problem "SeaMonkey v2.11 - v2.48 don't start as portable".
   * Fix bug "Toolkit don't run in Win32"
   * Refactoring.