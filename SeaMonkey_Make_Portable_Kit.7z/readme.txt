SeaMonkey make portable toolkit v2.0 for Windows.

Parameters: {x86|x64}

Supported:

x86 and x64 SeaMonkey version 2.x (tested up to v2.58a1 x86 amd AMD64)

Usage:

1) Unpack archive "SeaMonkey_Make_Portable_Kit.7z" in to any dir.
2) Copy only "SeaMonkey Setup *.exe" or seamonkey-*.*.zip in to
   ./SeaMonkey_Make_Portable_Kit
3) Open CMD console and type cd /d $path\SeaMonkey_Make_Portable_Kit and
   press Enter.
4) type "makeport x86" for 32 bit SeaMonkey or "makeport x64" for 64 bit
   SeaMonkey and press Enter.
5) Please wait for end makeport.cmd then Your have portable version SeaMonkey.
6) For opening a new instance of your SeaMonkey with another profile just set
   to "tmemutil.ini" in to section [Env] value "MOZ_NO_REMOTE" to 1. Example
   add string "MOZ_NO_REMOTE=1" (equivalent command line key "-no-remote") in
   to [Env] section:

   [Env]
   MOZ_NO_REMOTE=1

Notes:

   By default environment variable "MOZ_NO_REMOTE" don't exist (in to [Env]
   section set value "MOZ_NO_REMOTE=") for run more one copy of SeaMonkey
   (Mozilla FireFox, SeaMonkey v2.x, Thunderbird always use check
   "IsExist(MOZ_NO_REMOTE)" for run more thats one copy this independent
   profile.

   Command line options "-no-remote" have hight priority then "MOZ_NO_REMOTE"
   value.

History:

v2.0, 26.08.2019 20:05:23 +0300

   * Both x86 and x64 edition support,
   * Support SeaMonkey v2.52+ (rv55 or newer)
   * Refactoring.