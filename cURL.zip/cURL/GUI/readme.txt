A very easy GUI for cURL

Windows binary.

You can compile the source with Lazarus under Linux
Run without any problem.

First open proxy.cfg
if you want use proxy change it

target.cfg

open it and change the target folder.

This program run under the GPL

You can use this with download with under Firefox
GUI_curl [URL]