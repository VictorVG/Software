Rufus

https://github.com/pbatard/rufus/

Простое создание загрузочных USB-дисков

Rufus это утилита, которая помогает форматировать и создавать
загрузочные Flash/Pen/Key диски, карты памяти и т.д.

Rufus будет особенно полезен в случаях, когда вам необходимо:

  * создать загрузочный USB-диск из загрузочного ISO-образа
    (Windows, Linux, UEFI и др.)
  * работать на системах, которые не имеют установленной ОС
  * прошить BIOS или другую прошивку из-под DOS
  * запустить низкоуровневую утилиту

Несмотря на небольшой размер, Rufus умеет делать все необходимое!

Rufus работает очень быстро. Например, вдвое быстрее, чем UNetbootin
http://unetbootin.sourceforge.net/, Universal USB Installer
http://www.pendrivelinux.com/universal-usb-installer-easy-as-1-2-3> или
Windows 7 USB download tool <http://wudt.codeplex.com/ при создании
загрузочного Windows 7 USB-диска из ISO-образа. Rufus также немного
быстрее при создании загрузочного Linux USB-диска из ISO-образа.

Неполный список ISO-образов, с которыми Rufus умеет работать представлен
внизу страницы.

Поддерживает многие языки, в том числе и русский.

Системные требования:

Windows Vista/Server 2008 или новее, 32/64 бит.
После загрузки приложение готово к использованию.

Начиная с v2.8 b864 Windows XP / Server 2003 не поддерживаются!

Использование

Скачайте исполняемый файл и запустить его – установка не требуется.

Исполняемый файл имеет цифровую подпись, содержащую:

"Akeo Consulting" (v1.3.0 или более поздней версии)
"Pete Batard - Open Source Developer" (v1.2.0 или более ранней версии)

Несколько слов о поддержке DOS:

Если вы создаете DOS загрузочный диск и используете не-US клавиатуру,
Rufus выберет раскладку клавиатуры в соответствии с региональными
настройками вашей системы. В этом случае FreeDOS (http://www.freedos.org/),
который используется по умолчанию, будет использоваться вместо MS-DOS,
поскольку она поддерживает большее кол-во раскладок клавиатуры.

Несколько слов о поддержке ISO:

Все версии Rufus начиная с версии 1.1.0 позволяют создать загрузочный
USB-диск из ISO-образа (http://en.wikipedia.org/wiki/ISO_image).

Создать ISO-образ из физического диска или из набора файлов очень легко
с помощью программ для записи дисков CD, таких как свободно
распространяемые CDBurnerXP (http://cdburnerxp.se/) или ImgBurn
(http://www.imgburn.com/).

Несколько слов о UEFI и поддержке GPT:

Начиная с версии 1.3.2, Rufus поддерживает UEFI, а также GPT разделы
установочных носителей, это означает, что Rufus позволит вам установить
Windows 7, Windows 8 или Linux в полном EFI режиме.

Тем не менее, для полной поддержки UEFI/GPT необходима Windows Vista или
более поздние версии ОС Windows. Windows XP ограничивает создание UEFI
загрузочных дисков режимом MBR из-за ограничений операционной системы.

Часто задаваемые вопросы (FAQ)

Rufus FAQ доступен на https://github.com/pbatard/rufus/wiki/FAQ.

Для того чтобы оставить отзыв, сообщить об ошибке или предложить идею,
пожалуйста, используйте github https://github.com/pbatard/rufus/issues .
Также вы можете отправить его на e-mail mailto:pete@akeo.ie?subject=Rufus.

Лицензия

Открытое лицензионное соглашение GNU (GPL) версии 3
http://www.gnu.org/licenses/gpl.html или позднее.
Вы можете свободно распространять, изменять или даже продавать
программное обеспечение при соблюдении лицензии GPLv3.

Rufus создан со 100% открытым кодом https://github.com/pbatard/rufus
в среде MinGW32.

Исходный код

Вы можете клонировать git (http://git-scm.com/) репозиторий командой:

$ git clone git://github.com/pbatard/rufus

Дополнительные сведения см. в разделе проекта на
github https://github.com/pbatard/rufus .

Если вы разработчик, вы можете сильно помочь в развитии Rufus, прислав
свои патчи с изменениями.

Пожертвования

Поскольку постоянно задаются вопросы о пожертвованиях, поясняю, что на
странице нет кнопки пожертвовать.

Причина отсутствия возможности пожертвовать заключается в том, что, по
моему мнению, пожертвования не помогают в разработке программного
обеспечения, а только вызывают чувство вины у пользователей, которые не
пожертвовали.

Если вы все же настаиваете, то всегда можете сделать пожертвование в
Free Software Foundation http://www.fsf.org/, так как именно благодаря
FSF является возможным создание Rufus.

В любом случае, я хочу вам сказать СПАСИБО за вашу постоянную
поддержку и энтузиазм, связанные с этой небольшой программой: для меня
это очень важно!

Пожалуйста, продолжайте пользоваться Rufus безвозмезно, без каких-либо
пожертвований – вы ничего не должны!

1) Сравнение скорости работы Rufus и других приложений

Сравнения были проведены на компьютере с ОС Windows 7 x64 с процессором
Core 2 Duo, 4 ГБ RAM, с контроллером USB 3.0 и флешкой 16 ГБ USB 3.0
ADATA S102

Windows 7 x64:

Windows 7 USB/DVD Download Tool v1.0.30	00:08:10
Universal USB Installer v1.8.7.5	00:07:10
UNetbootin v1.1.1.1	                00:06:20
RMPrepUSB v2.1.638	                00:04:10
WiNToBootic v1.2                   	00:03:35
Rufus v1.1.1	                        00:03:25

Ubuntu 11.10 x86:

UNetbootin v1.1.1.1			00:01:45
RMPrepUSB v2.1.638			00:01:35
Universal USB Installer v1.8.7.5	00:01:20
Rufus v1.1.1				00:01:15

Slackware 13.37 x86:

UNetbootin v1.1.1.1			01:00:00
Universal USB Installer v1.8.7.5	00:24:35
RMPrepUSB v2.1.638			00:22:45
Rufus v1.1.1				00:20:15

2) Неполный список ISO-образов, с которыми Rufus умеет работать

Arch Linux <http://www.archlinux.org/
Archbang  http://archbang.org/
BartPE/pebuilder http://www.nu2.nu/pebuilder/
CentOS http://centos.org/
Damn Small Linux http://www.damnsmalllinux.org/
Debian  https://www.debian.org/
Fedora http://fedoraproject.org/
FreeDOS http://www.freedos.org/
FreeNAS http://www.freenas.org/
Gentoo http://www.gentoo.org/>
GParted http://gparted.org/
gNewSense http://www.gnewsense.org/
Hiren's Boot CD http://www.hiren.info/pages/bootcd
LiveXP http://reboot.pro/forum/52/
Knoppix http://knoppix.net/
KolibriOS http://kolibrios.org/
Kubuntu http://www.kubuntu.org/
Linux Mint http://linuxmint.com/
NT Password Registry Editor http://pogostick.net/%7Epnh/ntpasswd/
Parted Magic http://partedmagic.com/doku.php
Partition Wizard http://www.partitionwizard.com/partition-wizard-bootable-cd.html
Raspbian http://www.raspbian.org/
ReactOS http://reactos.org/
Red Hat http://www.redhat.com/
rEFInd http://www.rodsbooks.com/refind/
Slackware http://www.slackware.com/
Super Grub2 Disk http://www.supergrubdisk.org/category/download/supergrub2diskdownload/super-grub2-disk-stable/
Tails https://tails.boum.org/
Trinity Rescue Kit  http://trinityhome.org/
Ubuntu http://www.ubuntu.com/
Ultimate Boot CD http://www.ultimatebootcd.com/
Windows XP (SP2+)  http://msdn.microsoft.com/en-us/subscriptions/downloads/default.aspx#searchTerm=&ProductFamilyId=140&Languages=en&FileExtensions=.iso&PageSize=10&PageIndex=0&FileId=0
Windows Vista http://msdn.microsoft.com/en-us/subscriptions/downloads/default.aspx#searchTerm=&ProductFamilyId=146&Languages=en&FileExtensions=.iso&PageSize=10&PageIndex=0&FileId=0
Windows Server 2008 https://msdn.microsoft.com/en-us/subscriptions/downloads/default.aspx#searchTerm=&ProductFamilyId=351&Languages=en&FileExtensions=.iso&PageSize=10&PageIndex=0&FileId=0
Windows 7 http://msdn.microsoft.com/en-us/subscriptions/downloads/default.aspx#searchTerm=&ProductFamilyId=350&Languages=en&FileExtensions=.iso&PageSize=10&PageIndex=0&FileId=0
Windows 8 http://msdn.microsoft.com/en-us/subscriptions/downloads/default.aspx#searchTerm=&ProductFamilyId=481&Languages=en&FileExtensions=.iso&PageSize=10&PageIndex=0&FileId=0
Windows 8.1 http://msdn.microsoft.com/en-us/subscriptions/downloads/default.aspx#searchTerm=&ProductFamilyId=524&Languages=en&FileExtensions=.iso&PageSize=10&PageIndex=0&FileId=0
Windows Server 2012 http://www.microsoft.com/en/server-cloud/products/windows-server-2012-r2/
Windows 10  https://www.microsoft.com/en-us/software-download/techbench
Windows Server 2016 https://www.microsoft.com/en-us/evalcenter/evaluate-windows-server-technical-preview

Copyright © 2011-2015 Pete Batard/Akeo http://pete.akeo.ie/
